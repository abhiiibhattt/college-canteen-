Admin login details:

Username : admin

Password  : 123